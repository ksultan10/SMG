(() => {
/* global React, Bits */
const { useState, useEffect } = React;
const { Eyebrow } = window.Bits;

/* ============================================================
   PORTFOLIO — SECTION 1 — HERO
   "OUR WORK." — slideshow placeholder behind a dark overlay
   ============================================================ */

const SLIDES = [
  { tone: "warm",    label: "The Fort Residence · 2024" },
  { tone: "cool",    label: "Northridge Tower · 2023" },
  { tone: "storm",   label: "Beacon Hill Rebuild · 2017" },
  { tone: "neutral", label: "SMG Yard Office · 2022" },
  { tone: "gold",    label: "Lakeview Custom · 2024" },
];

const TONES = {
  warm:    "linear-gradient(135deg, #4a3a1a 0%, #2a2010 55%, #0a0a0a 100%)",
  cool:    "linear-gradient(140deg, #2a3140 0%, #15191f 55%, #050505 100%)",
  neutral: "linear-gradient(140deg, #3a3a3a 0%, #1a1a1a 55%, #050505 100%)",
  gold:    "linear-gradient(135deg, #6a5224 0%, #2a2010 60%, #0a0a0a 100%)",
  storm:   "linear-gradient(160deg, #2a2820 0%, #15140e 60%, #000 100%)",
};

function PortfolioHero() {
  const [i, setI] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setI((n) => (n + 1) % SLIDES.length), 4500);
    return () => clearInterval(t);
  }, []);

  return (
    <section data-section-id="portfolio-hero" data-screen-label="01 Portfolio Hero" style={{
      position: "relative", minHeight: "85vh", overflow: "hidden",
      display: "flex", alignItems: "flex-end",
      padding: "180px var(--gutter) 96px",
    }}>
      {/* Slideshow stack */}
      {SLIDES.map((s, idx) => (
        <div key={idx} aria-hidden="true" style={{
          position: "absolute", inset: 0, zIndex: 0,
          background: TONES[s.tone],
          opacity: i === idx ? 1 : 0,
          transition: "opacity 1400ms cubic-bezier(.4,0,.2,1)",
          filter: "grayscale(.85) contrast(1.08)",
        }} />
      ))}

      {/* Subtle gold bloom */}
      <div aria-hidden="true" style={{
        position: "absolute", inset: 0, zIndex: 1,
        background:
          "radial-gradient(ellipse 50% 35% at 75% 25%, rgba(206,166,77,.12), transparent 70%)",
        pointerEvents: "none",
      }} />

      {/* Dark overlay */}
      <div aria-hidden="true" style={{
        position: "absolute", inset: 0, zIndex: 2,
        background: "linear-gradient(180deg, rgba(0,0,0,.45) 0%, rgba(0,0,0,.4) 50%, rgba(0,0,0,.92) 100%)",
      }} />

      <div style={{ position: "relative", zIndex: 3, maxWidth: 1440, margin: "0 auto", width: "100%" }}>
        <Eyebrow>Portfolio · {SLIDES.length} featured</Eyebrow>
        <h1 style={{
          fontFamily: "var(--font-display)", fontWeight: 900,
          fontSize: "clamp(96px, 18vw, 280px)",
          lineHeight: 0.88, letterSpacing: "-.05em",
          textTransform: "uppercase", color: "#fff",
          margin: "32px 0 0",
        }}>
          Our work<span style={{ color: "var(--accent)" }}>.</span>
        </h1>
        <p style={{
          marginTop: 48, maxWidth: 560, fontSize: 20, lineHeight: 1.55,
          color: "var(--fg-muted)",
        }}>
          From custom homes to commercial complexes — every project, built to the same standard.
        </p>

        {/* Slide counter */}
        <div style={{
          marginTop: 64,
          display: "flex", alignItems: "center", gap: 24,
          fontFamily: "ui-monospace, Menlo, monospace",
          fontSize: 11, letterSpacing: ".25em", textTransform: "uppercase",
          color: "var(--fg-muted)",
        }}>
          <span style={{ color: "var(--accent)" }}>{String(i + 1).padStart(2, "0")}</span>
          <span style={{ width: 220, height: 1, background: "rgba(255,255,255,.15)", position: "relative", overflow: "hidden" }}>
            <span style={{
              position: "absolute", inset: 0,
              background: "var(--accent)",
              transform: `scaleX(${(i + 1) / SLIDES.length})`,
              transformOrigin: "left",
              transition: "transform 600ms cubic-bezier(.4,0,.2,1)",
            }} />
          </span>
          <span style={{ color: "rgba(255,255,255,.5)" }}>{String(SLIDES.length).padStart(2, "0")}</span>
          <span style={{ marginLeft: 24, color: "rgba(255,255,255,.5)" }}>{SLIDES[i].label}</span>
        </div>
      </div>
    </section>
  );
}

window.Sections = Object.assign(window.Sections || {}, { PortfolioHero });

})();
