(() => {
/* global React, Bits */
const { Eyebrow } = window.Bits;

/* ============================================================
   SPONSORSHIPS — SECTION 1 — HERO
   "GIVING BACK TO WOOD BUFFALO."
   ============================================================ */
function SponsHero() {
  return (
    <section data-section-id="sp-hero" data-screen-label="01 Spons Hero" style={{
      position: "relative", minHeight: "92vh", overflow: "hidden",
      display: "flex", alignItems: "flex-end",
      padding: "200px var(--gutter) 96px",
    }}>
      {/* Community event photo placeholder — warmer overlay */}
      <div aria-hidden="true" style={{
        position: "absolute", inset: 0, zIndex: 0,
        background:
          "linear-gradient(135deg, #2a2014 0%, #1a1208 45%, #0a0805 100%)",
      }}>
        <div style={{
          position: "absolute", inset: 0,
          background:
            "radial-gradient(ellipse 55% 40% at 70% 30%, rgba(206,166,77,.22), transparent 70%)," +
            "radial-gradient(ellipse 65% 45% at 20% 80%, rgba(221,193,124,.08), transparent 70%)",
          filter: "grayscale(.55) contrast(1.05)",
        }} />
        <div style={{
          position: "absolute", top: 120, right: "var(--gutter)",
          display: "flex", alignItems: "center", gap: 10,
          fontFamily: "ui-monospace, Menlo, monospace", fontSize: 10,
          letterSpacing: ".25em", color: "rgba(255,255,255,.3)",
        }}>
          <span style={{ width: 8, height: 8, borderRadius: 999, background: "var(--accent)" }} />
          COMMUNITY EVENT BG
        </div>
      </div>

      {/* Slightly softer overlay than home/about */}
      <div aria-hidden="true" style={{
        position: "absolute", inset: 0, zIndex: 1,
        background: "linear-gradient(180deg, rgba(20,12,4,.4) 0%, rgba(10,8,5,.35) 40%, rgba(0,0,0,.92) 100%)",
      }} />

      <div style={{ position: "relative", zIndex: 2, maxWidth: 1440, margin: "0 auto", width: "100%" }}>
        <Eyebrow>Sponsorships · Wood Buffalo</Eyebrow>
        <h1 style={{
          fontFamily: "var(--font-display)", fontWeight: 900,
          fontSize: "clamp(56px, 10vw, 152px)",
          lineHeight: 0.92, letterSpacing: "-.05em",
          textTransform: "uppercase", color: "#fff",
          margin: "32px 0 0", maxWidth: 1300,
        }}>
          Giving back<br/>
          to <span style={{ color: "var(--accent)" }}>Wood Buffalo</span>.
        </h1>
        <p style={{
          marginTop: 48, maxWidth: 620, fontSize: 22, lineHeight: 1.5,
          color: "var(--fg-muted)",
        }}>
          Community is built the same way buildings are — together.
        </p>
      </div>
    </section>
  );
}

window.Sections = Object.assign(window.Sections || {}, { SponsHero });

})();
