(() => {
/* global React, Bits */
const { Eyebrow } = window.Bits;

/* ============================================================
   ABOUT — SECTION 1 — HERO
   "BUILT IN FORT McMURRAY. BUILDING THE NORTH."
   ============================================================ */
function AboutHero() {
  return (
    <section data-section-id="about-hero" data-screen-label="01 About Hero" style={{
      position: "relative", minHeight: "92vh", overflow: "hidden",
      display: "flex", alignItems: "flex-end",
      padding: "200px var(--gutter) 96px",
    }}>
      {/* Cinematic team / job site photo placeholder */}
      <div aria-hidden="true" style={{
        position: "absolute", inset: 0, zIndex: 0,
        background:
          "linear-gradient(140deg, #1a1410 0%, #0a0805 45%, #000 100%)",
      }}>
        <div style={{
          position: "absolute", inset: 0,
          background:
            "radial-gradient(ellipse 60% 45% at 80% 30%, rgba(206,166,77,.14), transparent 70%)," +
            "radial-gradient(ellipse 70% 50% at 15% 85%, rgba(206,166,77,.05), transparent 70%)",
          filter: "grayscale(.85) contrast(1.08)",
        }} />
        <div style={{
          position: "absolute", top: 120, right: "var(--gutter)",
          display: "flex", alignItems: "center", gap: 10,
          fontFamily: "ui-monospace, Menlo, monospace", fontSize: 10,
          letterSpacing: ".25em", color: "rgba(255,255,255,.3)",
        }}>
          <span style={{ width: 8, height: 8, borderRadius: 999, background: "var(--accent)" }} />
          CINEMATIC PHOTO BG
        </div>
      </div>

      {/* Dark overlay for legibility */}
      <div aria-hidden="true" style={{
        position: "absolute", inset: 0, zIndex: 1,
        background: "linear-gradient(180deg, rgba(0,0,0,.55) 0%, rgba(0,0,0,.4) 40%, rgba(0,0,0,.9) 100%)",
      }} />

      <div style={{ position: "relative", zIndex: 2, maxWidth: 1440, margin: "0 auto", width: "100%" }}>
        <Eyebrow>About — Est. 2013</Eyebrow>
        <h1 style={{
          fontFamily: "var(--font-display)", fontWeight: 900,
          fontSize: "clamp(56px, 10vw, 152px)",
          lineHeight: 0.92, letterSpacing: "-.05em",
          textTransform: "uppercase", color: "#fff",
          margin: "32px 0 0", maxWidth: 1300,
        }}>
          Built in<br/>
          Fort <span style={{ color: "var(--accent)" }}>McMurray</span>.<br/>
          Building the north.
        </h1>
        <p style={{
          marginTop: 48, maxWidth: 600, fontSize: 20, lineHeight: 1.55,
          color: "var(--fg-muted)",
        }}>
          Founded in 2013, scaling toward Edmonton and beyond.
        </p>
      </div>
    </section>
  );
}

window.Sections = Object.assign(window.Sections || {}, { AboutHero });

})();
