(() => {
/* global React, Bits */
const { Eyebrow } = window.Bits;

/* ============================================================
   CONTACT — SECTION 1 — HERO
   "LET'S BUILD SOMETHING."
   Minimal: pure black, single gold accent line
   ============================================================ */
function ContactHero() {
  return (
    <section data-section-id="ct-hero" data-screen-label="01 Contact Hero" style={{
      position: "relative", overflow: "hidden",
      padding: "200px var(--gutter) 120px",
      background: "#000",
    }}>
      {/* Single gold accent line — drawn from left, settles at ~60% width */}
      <span aria-hidden="true" style={{
        position: "absolute", top: 180, left: 0,
        height: 1, width: "62%",
        background: "linear-gradient(90deg, var(--accent) 0%, rgba(206,166,77,.4) 70%, transparent 100%)",
      }} />

      {/* Subtle radial gold wash, top-right */}
      <div aria-hidden="true" style={{
        position: "absolute", inset: 0, pointerEvents: "none",
        background: "radial-gradient(ellipse 45% 35% at 90% 0%, rgba(206,166,77,.08), transparent 70%)",
      }} />

      {/* Top meta row */}
      <div style={{
        position: "relative", maxWidth: 1440, margin: "0 auto",
        display: "flex", justifyContent: "space-between", alignItems: "center",
        marginBottom: 80,
        fontFamily: "ui-monospace, Menlo, monospace", fontSize: 10,
        letterSpacing: ".3em", color: "var(--fg-subtle)",
      }}>
        <span>SMG · CONTACT · 05 / 05</span>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
          <span style={{ width: 6, height: 6, borderRadius: 999, background: "var(--accent)" }} />
          REPLY WITHIN 1 BUSINESS DAY
        </span>
      </div>

      <div style={{ position: "relative", maxWidth: 1440, margin: "0 auto" }}>
        <Eyebrow>Contact</Eyebrow>
        <h1 style={{
          fontFamily: "var(--font-display)", fontWeight: 900,
          fontSize: "clamp(64px, 12vw, 200px)",
          lineHeight: 0.9, letterSpacing: "-.05em",
          textTransform: "uppercase", color: "#fff",
          margin: "32px 0 0", maxWidth: 1500,
        }}>
          Let's build<br/>
          <span style={{ color: "var(--accent)" }}>something</span>.
        </h1>
        <p style={{
          marginTop: 56, maxWidth: 600, fontSize: 22, lineHeight: 1.5,
          color: "var(--fg-muted)",
        }}>
          Tell us about your project. We'll get back to you within one business day.
        </p>
      </div>
    </section>
  );
}

window.Sections = Object.assign(window.Sections || {}, { ContactHero });

})();
