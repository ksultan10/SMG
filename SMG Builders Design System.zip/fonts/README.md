# Fonts

This folder holds web font files used by the SMG Builders design system.

## Currently loaded
- **Inter** — loaded from Google Fonts (`@import` at top of `colors_and_type.css`). Weights: 400, 500, 600, 700, 900.

## Substitution flag — Helvetica
Helvetica Bold is the canonical display face for SMG Builders. Helvetica is not freely web-licensed; we are currently substituting **Inter Black (900)** as the loaded display fallback.

To swap in true Helvetica:
1. Procure a Helvetica web license (e.g. via Linotype / Monotype Fonts).
2. Drop the `.woff2` files into this folder.
3. Add an `@font-face` declaration at the top of `colors_and_type.css`.
4. Confirm the order of `--font-display` so Helvetica resolves before Inter.

## Why Inter Black?
At display sizes with `letter-spacing: -0.05em`, Inter Black approximates Helvetica Bold's stance closely. The most visible differences are in `R`, `a`, and `t` terminals — acceptable for prototyping, less acceptable for production brand work.
